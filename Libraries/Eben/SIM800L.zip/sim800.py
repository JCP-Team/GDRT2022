import logging
import re
import time
from enum import Enum
from typing import Union, Tuple

try:
    import serial
except:
    pass

try:
    from RPi import GPIO
except:
    pass

from healthcheck_service.health_checker.modems.base_modem import BaseModem
from healthcheck_service.health_checker.utils.time import wait

logger = logging.getLogger(__name__)


class NetworkRegistration(Enum):
    """
    Enum for Network Registration State
    """

    NOT_REGISTERED_NOT_SEARCHING = 0
    REGISTERED_HOME = 1
    NOT_REGISTERED_SEARCHING = 2
    REGISTRATION_DENIED = 3
    REGISTRATION_UNKNOWN = 4
    REGISTERED_ROAMING = 5


class Sim800LException(Exception):
    """
    Custom SIM800L Exception class

    Used for specific SIM800L exceptions
    For example: not getting a response, error on certain commands, etc.
    """

    def __init__(self, _msg: str):
        super().__init__(_msg)

        # Log Error
        logger.error(_msg)


class Sim800(BaseModem):
    def __init__(self, _port: str, _baudrate: int):
        super().__init__()

        # Create Serial Handle
        self.serial_handle = serial.Serial(port=_port, baudrate=_baudrate)

    def __clear_buffer(self):
        self.serial_handle.read_all()

    def __disable_echo(self):
        """
        Disable Echo Mode of Modem

        By sending AT and checking if the response contains AT we can validate if the echo mode is disabled.
        A maximum of 10 retries with a 1s delay.

        Command:
            ATE0

        No Response expected.

        Returns: True on success, otherwise False

        """

        for _ in range(10):
            # Send command to switch off echo
            self.__send_cmd("ATE0\r\n", ("",), 500, 1, 1)

            # Send AT command check if response contains AT
            response, success = self.__send_cmd('AT\r\n', ('OK\r\n',), 500, 3, 3)

            if b'AT\r\n' not in response:
                return True

            # Failed, try again in 1s
            time.sleep(1)

        return False

    def __send_cmd(self, _send: Union[bytes, str], _expected_responses: Tuple,
                   _read_timeout_ms: int = 500, _read_retry: int = 3, _send_retry: int = 3) -> Tuple[bytes, bool]:

        # Convert send data to bytes if string
        if isinstance(_send, str):
            send_data = bytes(_send, encoding="ascii")
        else:
            send_data = _send

        # Convert send data to bytes if string
        response_data = []
        for expected_response in _expected_responses:
            if isinstance(expected_response, str):
                response_data.append(bytes(expected_response, encoding="ascii"))
            else:
                response_data.append(expected_response)

        received_data = b''
        for _ in range(_send_retry):

            # Clear Buffer
            self.__clear_buffer()

            # Send Data
            self.serial_handle.write(send_data)
            logger.debug("->{}".format(send_data))

            # Read Response
            for _ in range(_read_retry):
                # Wait x ms
                time.sleep(_read_timeout_ms / 1000)

                # Receive Data
                received_data += self.serial_handle.read_all()
                logger.debug("<-{}".format(received_data))

                # Check for response
                if any(re.search(x, received_data) for x in response_data):
                    return received_data, True

        return received_data, False

    def __get_connection_status(self) -> str:
        """
        Query Current Connection Status

            Command:
                AT+CIPSTATUS

            Response:
                OK
                STATE: <state>

            Response_Parameters:
                <state>: A string parameter which indicates the progress of connecting
                    - IP INITIAL
                    - IP START
                    - IP CONFIG
                    - IP GPRSACT
                    - IP STATUS
                    - TCP CONNECTING / UDP CONNECTING / SERVER LISTENING
                    - CONNECT OK
                    - TCP CLOSING / UDP CLOSING
                    - TCP CLOSED / UDP CLOSED
                    - PDP DEACT

        Returns:
            CurrentConnectionStatus: Current Connection Status

        """
        response, success = self.__send_cmd('AT+CIPSTATUS\r\n', ('OK\r\n',), 500, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to current connection status: {}".format(response))

        # Unpack Response
        try:
            response = response.decode("ascii", "replace")
            status = re.findall(r'STATE: (.+)', response)[0].rstrip()

            logger.info("Current Connection Status: {}".format(status))
            return status

        except UnicodeDecodeError:
            raise Sim800LException("Unable to decode the current connection status response: {}".format(response))

        except (IndexError, KeyError, ValueError):
            raise Sim800LException("Unable to current connection status: {}".format(response))

    def __deactivate_gprs_pdp_context(self) -> bool:
        """
        Deactivate GPRS PDP Context (Shutdown)

        Command:
            AT+CIPSHUT

        Response:
            If close is successful: SHUT OK\n
            If close fails: ERROR

        Max Response Time: 65s

        If this command is executed in multi-connection mode, all of the IP connection will be shut.
        User can close gprs pdp context by AT+CIPSHUT. After it is closed, the status is IP INITIAL.
        If "+PDP: DEACT" urc is reported which means the gprs is released by the network, then user still
        needs to execute "AT+CIPSHUT" command to make PDP context come back to original state.

        Returns:
            bool: True on success. False otherwise.
        """
        response, success = self.__send_cmd('AT+CIPSHUT\r\n', ('SHUT OK', 'ERROR'), 500, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to deactivate GPRS PDP context: {}".format(response))

        # Check Response
        if b'SHUT OK' in response:
            logger.info("Successfully deactivated GPRS PDP context")
            return True
        else:
            logger.info("Error received trying to deactivate GPRS PDP Context: {}".format(response))
            return False

    def __close_connection(self, _force: bool = False) -> bool:
        """
        Close TCP or UDP Connection

        AT+CIPCLOSE only closes connection at corresponding status of TCP/UDP stack.
        To see the status use AT+CIPSTATUS command.
        Status should be:
            - TCP CONNECTING,
            - UDP CONNECTING,
            - SERVER LISTENING,
            - CONNECT OK in single-connection mode (see <state> parameter),
            - CONNECTING or CONNECTED in multi-connection mode (see <client state>),
            - OPENING or LISTENING in multi-connection mode (see <server state>)

        Otherwise it will return ERROR

        Command:
            AT+CIPCLOSE

        Response:
            If close is successfully:
            CLOSE OK

            If close fails:
            ERROR

        Args:
            _force (bool): If true, the command will be sent regardless of the current status

        Returns:
            bool: True on success. False otherwise.
        """

        # If force not set, check current status first.
        if not _force:
            # Check current status
            current_status = self.__get_connection_status()

            # Check if the status is correct
            if current_status not in ["UDP CONNECTING", "CONNECT OK"]:
                logger.warning(
                    "Unable to close connection (assumed already closed), state is: {}".format(current_status))
                return True

        response, success = self.__send_cmd('AT+CIPCLOSE\r\n', ('CLOSE OK', 'ERROR'), 500, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to close connection: {}".format(response))

        # Check Response
        if b'CLOSE OK' in response:
            logger.info("Successfully closed connection")
            return True
        else:
            logger.info("Error received trying to close connection: {}".format(response))
            return False

    def __set_apn(self, _apn: str):
        """
        Start Task and Set APN

        This will change the status from IP INITIAL to IP START

        Command:
            AT+CSTT=apn

        Reponse:
            OK
            ERROR

        Parameters:
            _apn: APN Name

        Returns:
            bool: True on success

        """
        command = 'AT+CSTT={}\r\n'.format(_apn)

        response, success = self.__send_cmd(command, ('OK\r\n', 'ERROR\r\n'), 500, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to set APN, response: {}".format(response))

        # Check Response
        if b'OK' in response:
            logger.info("Successfully set APN to: {}".format(_apn))
            return True
        else:
            logger.info("Error received trying to set APN to: {}".format(_apn))
            return False

    def __start_wireless_connection(self):
        """
        Bring up wireless connection (GPRS or CSD)

        State Change: IP START to IP GPRSACT

        AT+CIICR only activates moving scene at the status of IP START,
        after operating this Command is executed, the state will be changed to IP CONFIG.

        After module accepts the activated operation, if it is activated successfully,
        module state will be changed to IP GPRSACT, and it responds OK, otherwise it will respond ERROR.

        Command:
            AT+CIICR

        Response:
            OK
            ERROR

        Returns:
            bool: True on success. False otherwise.
        """

        response, success = self.__send_cmd('AT+CIICR\r\n', ('OK\r\n', 'ERROR\r\n'), 500, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to start wireless connection: {}".format(response))

        # Check Response
        if b'OK' in response:
            logger.info("Started wireless connection")
            return True
        else:
            logger.error("Error received trying to start wireless connection")
            return False

    def __get_local_ip_address(self, _force: bool = False):
        """
        Get the local IP address

        Only after PDP context is activated, local IP address can be obtained by AT+CIFSR,
        otherwise it will respond ERROR. To see the status use AT+CIPSTATUS command.
        Status should be:
            - IP GPRSACT
            - TCP CONNECTING
            - UDP CONNECTING
            - SERVER LISTENING
            - IP STATUS
            - CONNECT OK
            - TCP CLOSING
            - UDP CLOSING
            - TCP CLOSED
            - UDP CLOSED (single-connection mode)
            - IP STATUS or IP PROCESSING (multi-connection mode)

        Command:
            AT+CIFSR

        Response:
            <IP Address>
                or
            ERROR

        Response_Paramaters:
            <IP_Address>:
                IP address in the format x.x.x.x

        Args:
            _force (bool): Force the command regardless if in the correct status. Default to False.

        Returns:
            str: IP Address in format x.x.x.x
        """

        # If force not set, check current status first.
        if not _force:
            # Check current status
            current_status = self.__get_connection_status()

            # Check if the status is correct
            if current_status not in [
                "IP GPRSACT",
                "TCP CONNECTING",
                "UDP CONNECTING",
                "SERVER LISTENING",
                "IP STATUS",
                "CONNECT OK",
                "TCP CLOSING",
                "UDP CLOSING",
                "TCP CLOSED",
                "UDP CLOSED",
                "IP STATUS",
                "IP PROCESSING"
            ]:
                logger.warning("Unable to get local ip address, state is: {}".format(current_status))
                return False

        response, success = self.__send_cmd('AT+CIFSR\r\n', (r'(\d+\.\d+\.\d+\.\d+)', 'ERROR\r\n'), 500, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to get local ip address: {}".format(response))

        # Unpack Response
        try:
            response = response.decode("ascii", "replace")

            ip_address = re.findall(r'(\d+\.\d+\.\d+\.\d+)', response)[0]

            logger.info("Local IP Address: {}".format(ip_address))
            return ip_address

        except UnicodeDecodeError:
            raise Sim800LException("Unable to decode the local ip address response: {}".format(response))

        except (IndexError, KeyError, ValueError):
            raise Sim800LException("Unable to get local ip address: {}".format(response))

    def __tcp_connect(self, _ip_address: str, _port: int) -> bool:
        command = 'AT+CIPSTART="TCP","{}","{}"\r\n'.format(_ip_address, _port)
        responses = ('ALREADY CONNECT\r\n', 'CONNECT OK\r\n', 'CONNECT FAIL\r\n')

        response, success = self.__send_cmd(command, responses, 1000, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to create TCP connection({}:{}): {}".format(_ip_address, _port, response))

        # Check Response
        if b'CONNECT OK' in response:
            logger.info("TCP Connection created to {}:{}".format(_ip_address, _port))
            return True
        elif b'ALREADY CONNECT' in response:
            logger.warning("TCP Connection already created to {}:{}".format(_ip_address, _port))
            return True
        else:
            logger.error("TCP Connection({}:{}) failed, response:{}".format(_ip_address, _port, response))
            return False

    def __udp_connect(self, _ip_address: str, _port: int) -> bool:
        """
        Start Up TCP or UDP Connection

        This command allows establishment of a TCP/UDP connection only when the state is IP INITIAL or
        IP STATUS when it is in single state.  In multi-IP state, the state is in IP STATUS only.
        So it is necessary to process "AT+CIPSHUT" before user establishes a TCP/UDP connection with this
        command when the state is not IP INITIAL or IP STATUS.

        When module is in multi-IP state, before this command is executed,
        it is necessary to process "AT+CSTT, AT+CIICR, AT+CIFSR".

        Command:
            AT+CIPSTART="UDP", "<IP Address>","<Port>"

        Response:
            If format is right response: OK\r\n
            Response when connection exists: ALREADY CONNECT\r\n
            Response when connection was successful: CONNECT OK\r\n
            Otherwise:
                STATE: <state>\r\n
                CONNECT FAIL\r\n

        Max Response Time: 160s

        Args:
            _ip_address (str): IP Address string (x.x.x.x)
            _port (int): Port to connect to

        Returns:
            bool: True on success. Otherwise False.
        """
        command = 'AT+CIPSTART="UDP","{}","{}"\r\n'.format(_ip_address, _port)
        responses = ('ALREADY CONNECT\r\n', 'CONNECT OK\r\n', 'CONNECT FAIL\r\n')

        response, success = self.__send_cmd(command, responses, 1000, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to create UDP connection({}:{}): {}".format(_ip_address, _port, response))

        # Check Response
        if b'CONNECT OK' in response:
            logger.info("UDP Connection created to {}:{}".format(_ip_address, _port))
            return True
        elif b'ALREADY CONNECT' in response:
            logger.warning("UDP Connection already created to {}:{}".format(_ip_address, _port))
            return True
        else:
            logger.error("UDP Connection({}:{}) failed, response:{}".format(_ip_address, _port, response))
            return False

    def __wait_for_boot(self, _timeout_s: int = 30) -> bool:
        data = self.serial_handle.read_all()

        timeout = time.time() + _timeout_s
        while True:
            self.serial_handle.write(b'AT\r\n')
            time.sleep(1)

            if time.time() > timeout:
                logger.warning("Wait for boot timeout expired, continuing...")
                return False

            data += self.serial_handle.read_all()
            logger.debug("Data: {}".format(data))

            # Wait for RDY\r\n
            if b'+CPIN: READY\r\n' not in data:
                continue

            # Wait for +CFUN: 1\r\n
            if b'Call Ready\r\n' not in data:
                continue

            # Wait for SIM READY
            if b'SMS Ready\r\n' not in data:
                continue

            break  # Success

        return True

    def __check_network_registration(self) -> NetworkRegistration:
        """
        Check Network Registration

        TA returns the status of result code presentation and an integer <stat>
        which shows whether the network has currently indicated the registration
        of the ME. Location information elements <lac> and <ci> are returned
        only when <n>=2 and ME is registered in the network.

        Command:
            AT+CREG?

        Response:
            +CREG: <n>,<stat>[,<lac>,<ci>]

            OK

        If error is related to ME functionality:
            +CME ERROR: <err>


        Response_Parameters:
            <n>
                0 Disable network registration unsolicited result code
                1 Enable network registration unsolicited result code +CREG: <stat>
                2 Enable network registration unsolicited result code with
                  location information +CREG: <stat>[,<lac>,<ci>]

            <stat>
                 0 Not registered, MT is not currently searching a new operator to register to
                 1 Registered, home network
                 2 Not registered, but MT is currently searching a new operator to register to
                 3 Registration denied
                 4 Unknown
                 5 Registered, roaming

            <lac>
                String type (string should be included in quotation marks);
                two byte location area code in hexadecimal format

            <ci>
                String type (string should be included in quotation marks);
                two byte cell ID in hexadecimal format

        Returns:
             NetworkRegistration: Network Registration Status

        """

        response, success = self.__send_cmd('AT+CREG?\r\n', ("OK\r\n",), 500, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to check network registration: {}".format(response))

        # Unpack Response
        try:
            response = response.decode("ascii", "replace")

            n, stat = re.findall(r'\+CREG: ([0-9]+?),([0-9]+?)', response)[0]

            network_registration = NetworkRegistration(int(stat))

            logger.info("Network Registration: {}".format(network_registration))
            return network_registration

        except UnicodeDecodeError:
            raise Sim800LException("Unable to decode the network registration response: {}".format(response))

        except (IndexError, KeyError, ValueError):
            raise Sim800LException("Unable to find network registration in response: {}".format(response))

    def __check_signal_quality(self):
        """
        Check signal quality

        Execution Command returns received signal strength indication <rssi>
        and channel bit error rate <ber> from the ME. Test Command returns
        values supported by the TA.

        Command:
            AT+CSQ

        Response:
            +CSQ: <rssi>,<ber>

            OK

        If error is related to ME functionality:
            +CME ERROR: <err>

        Response_Parameters:
            <rssi>
                0 -115 dBm or less
                1 -111 dBm
                2...30 -110... -54 dBm
                31 -52 dBm or greater
                99 not known or not detectable

            <ber> (in percent)
                0...7 As RXQUAL values in the table in GSM 05.08 [20] (subclause 7.2.4)
                99 Not known or not detectable

        Returns:
            int: RSSI Value in dBm (-999 is not known or not detecable)

        """

        response, success = self.__send_cmd('AT+CSQ\r\n', ('OK\r\n',), 1000, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to check signal quality: {}".format(response))

        # Unpack Response
        try:
            # Convert response to ASCII
            response = response.decode("ascii", "replace")

            rssi, ber = re.findall(r'\+CSQ: (-?[0-9]+?),([0-9]+?)', response)[0]

            # Convert from RAW to dBM ( rssi = 4 * raw_value - 115 )
            rssi = int(rssi)

            if rssi == 99:
                rssi = -999
            else:
                rssi = rssi * 4 - 115

            logger.info("RSSI: {}dBm".format(rssi))
            return rssi

        except UnicodeDecodeError:
            raise Sim800LException("Unable to decode the signal quality response: {}".format(response))

        except (IndexError, KeyError, ValueError):
            raise Sim800LException("Unable to get signal quality in response: {}".format(response))

    def __check_gprs_attach_status(self):
        """
        Check GPRS Attach Status

        Command:
            AT+CGATT?

        Response:
            +CGATT: <state>
            OK

        Response_Parameters:
            <state>:
                Indicates the state of GPRS attachment
                    0 Detached
                    1 Attached

                Other values are reserved and will result in an ERROR response to the Write Command

        Returns:
             bool: True is attached
        """
        response, success = self.__send_cmd('AT+CGATT?\r\n', ('OK\r\n',), 500, 3, 3)

        # Check if failed
        if not success:
            raise Sim800LException("Unable to check GPRS attach status: {}".format(response))

        # Unpack Response
        try:
            response = response.decode("ascii", "replace")

            attach = re.findall(r'\+CGATT: (-?[0-9]+?)', response)[0]

            # Convert from RAW to dBM ( y = 4x-115 )
            attach = bool(int(attach))
            logger.info("GPRS Attach Status: {}".format(attach))
            return attach

        except UnicodeDecodeError:
            raise Sim800LException("Unable to decode the GPRS attach status response: {}".format(response))

        except (IndexError, KeyError, ValueError):
            raise Sim800LException("Unable to check GPRS attach status: {}".format(response))

    def setup(self, _apn: str) -> bool:
        # TODO: Add retries to the setup sequence

        try:
            # Disable Echo
            self.__disable_echo()

            # Clear Buffer
            self.__clear_buffer()

            # Check Modem Status
            self.__check_network_registration()
            self.__check_signal_quality()
            self.__check_gprs_attach_status()

            # Deactivate GPRS PDP Context. This assures a known starting position/status
            # State: ??? -> IP INITIAL
            if not self.__deactivate_gprs_pdp_context():
                return False

            # Set APN
            # State: IP INITIAL -> IP START
            if not self.__set_apn(_apn):
                return False

            # Bring up wireless connection
            # State: IP START -> IP GPRSACT
            if not self.__start_wireless_connection():
                return False

            # Get IP Address
            # State: IP GPRSACT -> IP STATUS
            if not self.__get_local_ip_address():
                return False

            # Now ready to create connection and send data
            return True

        except Sim800LException as ex:
            logger.error("Received exception during setup: {}".format(ex))
            return False

    def send_sms(self, _number: str, _message: str):
        # Set SMS system into text mode, as oppsed to PDU mode
        self.__send_cmd('AT+CMGF=1\r\n', ('OK\r\n',), 1000, 10, 2)

        # Go Into Send Mode
        self.__send_cmd('AT+CMGS="{}"\r\n'.format(_number), ('>',), 1000, 5, 1)

        # Send Data
        self.__send_cmd('{}'.format(_message) + '\x1A', (r'\+CMGS',), 1000, 10, 1)

        # Delete Any SMS in storage
        self.__send_cmd('AT+CMGD=1,4\r\n', (r'OK',), 1000, 10, 1)

    def send_udp_data(self, _ip_address: str, _port: int, _data: bytes,
                      _expected_resp: bytes, _timeout_s: int) -> Tuple[bool, bytes]:
        try:
            # Start UDP Connection
            self.__udp_connect(_ip_address, _port)

            # Go into "send mode"
            self.__send_cmd('AT+CIPSEND={}\r\n'.format(len(_data)), ('\r\n',), 500, 2, 2)

            # Send data
            received_data, result = self.__send_cmd(_data, ('\r\nSEND OK\r\n',), 500, 1, 1)

            # Wait for more data
            timeout = time.time() + _timeout_s
            while time.time() < timeout:
                received_data += self.serial_handle.read_all()
                if _expected_resp in received_data:
                    break
                time.sleep(0.01)

            # Remove SEND OK from received_data
            if received_data:
                received_data = received_data.replace(b'\r\nSEND OK\r\n', b'')

            # Close UDP Connection
            self.__close_connection()

            return True, received_data
        except Sim800LException:
            return False, b''

    def close_serial_handle(self):
        self.serial_handle.close()

    def reset_device(self):
        # Switch Off Power Supply
        GPIO.output(23, GPIO.LOW)

        # Wait 5s
        wait(logger, 5, "Switch Off Modem")

        # Switch On Power Supply
        GPIO.output(23, GPIO.HIGH)

        # Toggle PWR Pin High for 3s
        GPIO.output(24, GPIO.LOW)
        time.sleep(3)
        GPIO.output(24, GPIO.HIGH)

        self.__wait_for_boot()


if __name__ == "__main__":
    # Set Root Logger Level
    logger = logging.getLogger("")
    logger.setLevel(logging.DEBUG)

    # Add the console handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(logging.Formatter('%(asctime)s\t%(levelname)s\t%(message)s'))
    logger.addHandler(ch)

    # Setup GPIO
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(True)
    GPIO.setup(23, GPIO.OUT)
    GPIO.setup(24, GPIO.OUT)

    sim_800 = Sim800("/dev/serial0", 9600)
    sim_800.reset_device()
    sim_800.setup("internet")  # Not really required, but oh well
