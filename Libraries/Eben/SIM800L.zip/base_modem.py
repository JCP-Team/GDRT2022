from abc import abstractmethod
from typing import Tuple


class BaseModem:
    def __init__(self):
        pass

    @abstractmethod
    def setup(self, _apn: str) -> bool:
        pass

    @abstractmethod
    def send_sms(self, _number: str, _message: str):
        pass

    @abstractmethod
    def send_udp_data(self, _ip_address: str, _port: int, _data: bytes,
                      _expected_resp: bytes, _timeout_s: int) -> Tuple[bool, bytes]:
        pass

    @abstractmethod
    def close_serial_handle(self) -> None:
        pass

    @abstractmethod
    def reset_device(self) -> None:
        pass
